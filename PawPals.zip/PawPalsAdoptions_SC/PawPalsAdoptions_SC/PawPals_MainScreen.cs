﻿using System;
using System.Data;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PawPalsAdoptions_SC
{
    public partial class PawPals_MainScreen : Form
    {
        public PawPals_MainScreen()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void RegisterPet_btn_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm();
            registerForm.ShowDialog();
        }

        private void AdoptionDatabase_btn_Click(object sender, EventArgs e)
        {
            AdoptionDatabase adoption_Database = new AdoptionDatabase();
            adoption_Database.ShowDialog();
        }

        private void PawPals_MainScreen_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void CustomerCheckOut_btn_Click(object sender, EventArgs e)
        {
            Checkout_Form checkout_Form = new Checkout_Form();
            checkout_Form.ShowDialog(); 
        }
    }
}
