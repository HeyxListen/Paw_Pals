﻿namespace PawPalsAdoptions_SC
{
    partial class RegistrationExceptionHandling_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrationExceptionHandling_Form));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.exceptionHandle_lbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PawPalsAdoptions_SC.Properties.Resources.PawPalsTP2;
            this.pictureBox1.Location = new System.Drawing.Point(12, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(145, 136);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // exceptionHandle_lbl
            // 
            this.exceptionHandle_lbl.AutoSize = true;
            this.exceptionHandle_lbl.Location = new System.Drawing.Point(189, 18);
            this.exceptionHandle_lbl.Name = "exceptionHandle_lbl";
            this.exceptionHandle_lbl.Size = new System.Drawing.Size(0, 13);
            this.exceptionHandle_lbl.TabIndex = 4;
            // 
            // RegistrationExceptionHandling_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 229);
            this.Controls.Add(this.exceptionHandle_lbl);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RegistrationExceptionHandling_Form";
            this.Text = "RegistrationExceptionHandling_Form";
            this.Load += new System.EventHandler(this.RegistrationExceptionHandling_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label exceptionHandle_lbl;
    }
}