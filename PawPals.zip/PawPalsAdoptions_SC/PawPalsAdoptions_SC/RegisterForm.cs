﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace PawPalsAdoptions_SC
{
    public partial class RegisterForm : Form
    {

        const string DELIM = ",";
        //Verifying exception handling errors for Write
        //string FILENAME = @"C:\Users\defaultuser0\PawPalsRegistry.txt";
        //string FILENAME = "23123" + @"\PawPalsRegistry.txt";

        string FILENAME = Path.GetDirectoryName(Application.ExecutablePath) + @"\PawPalsRegistry.txt";
        string species, petName, gender, petSize, age, type, furLength, notes, underscore = "_";

        private void RegisterForm_Load(object sender, EventArgs e)
        {

        }

        bool tempKids, tempPets, tempMature, tempSpecialCare;
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Cat_img.Visible = false;
            Dog_img.Visible = true;
            PetProperties_pnl.Visible = true;
            Hypoallergenic_btn.Visible = true;
            SizeXS_rbtn.Text = "X-Small (1-10 lbs)";
            SizeS_rbtn.Text = "Small (11-20 lbs)";
            SizeM_rbtn.Text = "Medium (21-40 lbs)";
            SizeL_rbtn.Visible = true;

        }

        private void SpeciesCat_rbtn_CheckedChanged(object sender, EventArgs e)
        {
            Cat_img.Visible = true;
            Dog_img.Visible = false;
            PetProperties_pnl.Visible = true;
            Hypoallergenic_btn.Visible = false;
            SizeXS_rbtn.Text = "Small (1-5 lbs)";
            SizeS_rbtn.Text = "Medium (6-9 lbs)";
            SizeM_rbtn.Text = "Large (10+ lbs)";
            SizeL_rbtn.Visible = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ClearRegistration_Btn_Click(object sender, EventArgs e)
        {
            SpeciesDog_rbtn.Checked = false;
            SpeciesCat_rbtn.Checked = false;
            nameTextBox.Clear();
            GenderM_rbtn.Checked = false;
            GenderF_rbtn.Checked = false;
            SizeXS_rbtn.Checked = false;
            SizeS_rbtn.Checked = false;
            SizeM_rbtn.Checked = false;
            SizeL_rbtn.Checked = false;
            Age_lstbx.ClearSelected();
            BreedorColor_txtbx.Text = "";
            ShortHair_rbtn.Checked = false;
            MedHair_rbtn.Checked = false;
            LongHair_rbtn.Checked = false;
            Hypoallergenic_btn.Checked = false;
            TemperamentKids_ckbx.Checked = false;
            TemperamentMature_ckbx.Checked = false;
            TemperamentOtherPets_ckbx.Checked = false;
            TemperamentSpecialCare_ckbx.Checked = false;
            Notes_txtbx.Text = "";
            Dog_img.Visible = false;
            Cat_img.Visible = false;
            PetProperties_pnl.Visible = false;
            LogOutput_txtbx.AppendText("Cleared...\n");
        }

        private void SubmitRegistration_btn_Click(object sender, EventArgs e)
        {
            try
            {
                //Species Entry
                bool isChecked = SpeciesDog_rbtn.Checked;
                if (isChecked)
                    species = SpeciesDog_rbtn.Text;
                else
                    species = SpeciesCat_rbtn.Text;
                //Randomized ID - We will assign a 6 digit Randomized ID to each pet input into the System
                //Name Entry
                //If a name is not assigned, we will included a default name, which will be the species, an underscore, and a 4 digit randomized number.
                //The personnel should update the name at a later time on another tab

                if (nameTextBox.Text == "")
                {
                    int randomNumber;
                    Random ranNumberGenerator = new Random();
                    randomNumber = ranNumberGenerator.Next(0001, 9999);
                    petName = species.ToLower() + underscore + randomNumber;
                }
                else
                    petName = nameTextBox.Text;
                //Gender Entry - Radio Button Check
                if (GenderM_rbtn.Checked == true)
                    gender = "Male";
                else
                {
                    gender = "Female";
                }
                //Size Entry - Radio Button Check
                //if they are a dog, we will check and assign a dog range
                if (species == "Dog")
                {
                    if (SizeXS_rbtn.Checked == true)
                        petSize = "X-Small";
                    else
                    {
                        if (SizeS_rbtn.Checked == true)
                            petSize = "Small";
                        else
                        {
                            if (SizeM_rbtn.Checked == true)
                                petSize = "Medium";
                            else
                                if (SizeL_rbtn.Checked == true)
                                petSize = "Large";
                            else
                                petSize = "Error";
                        }
                    }
                }
                //Else, they are a cat and should use the cat weight ranges
                else
                {
                    if (SizeXS_rbtn.Checked == true)
                        petSize = "Small";
                    else
                    {
                        if (SizeS_rbtn.Checked == true)
                            petSize = "Medium";
                        else
                            petSize = "Large";
                    }
                }
                //Age Entry - Listbox Check
                age = Age_lstbx.SelectedItem.ToString();
                //Breed/FurColor Textbox Check
                type = BreedorColor_txtbx.Text;
                //Fur Type/Length
                if (ShortHair_rbtn.Checked == true)
                    furLength = ShortHair_rbtn.Text;
                else
                {
                    if (MedHair_rbtn.Checked == true)
                        furLength = MedHair_rbtn.Text;
                    else
                    {
                        if (LongHair_rbtn.Checked == true)
                            furLength = LongHair_rbtn.Text;
                        else
                            if (Hypoallergenic_btn.Checked == true && SpeciesDog_rbtn.Checked == true)
                            furLength = Hypoallergenic_btn.Text;
                        else
                            furLength = "Undefined";
                    }
                }
                //Checking Temperament Checkboxes... We will use a Boolean to define if the box returns a true value
                if (TemperamentKids_ckbx.Checked == true)
                    tempKids = true;
                else
                    tempKids = false;
                if (TemperamentOtherPets_ckbx.Checked == true)
                    tempPets = true;
                else
                    tempPets = false;
                if (TemperamentMature_ckbx.Checked == true)
                    tempMature = true;
                else
                    tempMature = false;
                if (TemperamentSpecialCare_ckbx.Checked == true)
                    tempSpecialCare = true;
                else
                    tempSpecialCare = false;
                //we will use the  text box to return a string if there are any additional notes
                notes = Notes_txtbx.Text;
                //finally, we will set a default value for avialable to true so that we can indicate that this pet is available for adoption.
                //available = true;
            }

            catch (NullReferenceException nullRefException)
            {
                LogOutput_txtbx.AppendText("Invalid input. Please complete form prior to submitting...");
            }
           
            try
            {
                //We can now use the similar "Clear" button coding to remove the selected fields, and we can also display a message for the user to know that the dog/cat
                //was successfully added. If any of the fields were not completed, we can prompt the user here.
                //we will use FileStream & StreamWriter to write to the document. In this event, we will use Append, so that we can continually add new data to the xisting file.
                FileStream outFile = new FileStream(FILENAME, FileMode.Append, FileAccess.Write);
                StreamWriter writer = new StreamWriter(outFile);
                writer.WriteLine(species + DELIM + petName + DELIM + gender + DELIM + petSize + DELIM + age + DELIM + type + DELIM + furLength + DELIM + tempKids.ToString() + DELIM + tempPets.ToString() + DELIM + tempMature.ToString() + DELIM + tempSpecialCare.ToString() + DELIM + notes + DELIM);
                SpeciesDog_rbtn.Checked = false;
                SpeciesCat_rbtn.Checked = false;
                nameTextBox.Clear();
                GenderM_rbtn.Checked = false;
                GenderF_rbtn.Checked = false;
                SizeXS_rbtn.Checked = false;
                SizeS_rbtn.Checked = false;
                SizeM_rbtn.Checked = false;
                SizeL_rbtn.Checked = false;
                Age_lstbx.ClearSelected();
                BreedorColor_txtbx.Text = "";
                ShortHair_rbtn.Checked = false;
                MedHair_rbtn.Checked = false;
                LongHair_rbtn.Checked = false;
                Hypoallergenic_btn.Checked = false;
                TemperamentKids_ckbx.Checked = false;
                TemperamentMature_ckbx.Checked = false;
                TemperamentOtherPets_ckbx.Checked = false;
                TemperamentSpecialCare_ckbx.Checked = false;
                Notes_txtbx.Text = "";
                writer.Close();
                outFile.Close();
            }
            catch (EndOfStreamException endOfStreamException)
            {
                LogOutput_txtbx.AppendText("The stream has ended prematurely. Please contact IT for assistance.\n");
            }
           
            catch (DirectoryNotFoundException directoryNotFoundException)
            {
                LogOutput_txtbx.AppendText("Directory not find. We could not write data to this directory...\nPlease run this application from a directory that is writeable...\n");
                //RegistrationExceptionHandling_Form registrationExceptionHandling_Form = new RegistrationExceptionHandling_Form();
                //registrationExceptionHandling_Form.Show(dirNotFound.ToString());
            }
            catch (UnauthorizedAccessException unauthorizedAccessException)
            {
                LogOutput_txtbx.AppendText("Unauthorized access to this directory...\nPlease run this application from a directory where you have permissions...\n");
                //RegistrationExceptionHandling_Form registrationExceptionHandling_Form = new RegistrationExceptionHandling_Form();
                //registrationExceptionHandling_Form.Show(dirNotFound.ToString());
            }
        }
    }
}
