﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PawPalsAdoptions_SC
{
    public partial class RegistrationExceptionHandling_Form : Form
    {
        public RegistrationExceptionHandling_Form()
        {
            InitializeComponent();
        }

        private void RegistrationExceptionHandling_Form_Load(object sender, EventArgs e)
        {

        }
    }
}
