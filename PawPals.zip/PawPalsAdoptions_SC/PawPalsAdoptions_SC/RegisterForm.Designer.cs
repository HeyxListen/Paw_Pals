﻿namespace PawPalsAdoptions_SC
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {

            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegisterForm));
            this.SpeciesDog_rbtn = new System.Windows.Forms.RadioButton();
            this.SpeciesCat_rbtn = new System.Windows.Forms.RadioButton();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Age_lstbx = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SizeXS_rbtn = new System.Windows.Forms.RadioButton();
            this.SizeM_rbtn = new System.Windows.Forms.RadioButton();
            this.SizeS_rbtn = new System.Windows.Forms.RadioButton();
            this.SizeL_rbtn = new System.Windows.Forms.RadioButton();
            this.SubmitRegistration_btn = new System.Windows.Forms.Button();
            this.ClearRegistration_btn = new System.Windows.Forms.Button();
            this.Special_pnl = new System.Windows.Forms.Panel();
            this.GenderM_rbtn = new System.Windows.Forms.RadioButton();
            this.GenderF_rbtn = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Hypoallergenic_btn = new System.Windows.Forms.RadioButton();
            this.LongHair_rbtn = new System.Windows.Forms.RadioButton();
            this.MedHair_rbtn = new System.Windows.Forms.RadioButton();
            this.ShortHair_rbtn = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.TemperamentMature_ckbx = new System.Windows.Forms.CheckBox();
            this.TemperamentSpecialCare_ckbx = new System.Windows.Forms.CheckBox();
            this.TemperamentOtherPets_ckbx = new System.Windows.Forms.CheckBox();
            this.TemperamentKids_ckbx = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.PetProperties_pnl = new System.Windows.Forms.Panel();
            this.Notes_txtbx = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.BreedorColor_txtbx = new System.Windows.Forms.TextBox();
            this.Cat_img = new System.Windows.Forms.PictureBox();
            this.Dog_img = new System.Windows.Forms.PictureBox();
            this.LogOutput_txtbx = new System.Windows.Forms.TextBox();
            this.Special_pnl.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.PetProperties_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Cat_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog_img)).BeginInit();
            this.SuspendLayout();
            // 
            // SpeciesDog_rbtn
            // 
            this.SpeciesDog_rbtn.AutoSize = true;
            this.SpeciesDog_rbtn.Location = new System.Drawing.Point(0, -1);
            this.SpeciesDog_rbtn.Name = "SpeciesDog_rbtn";
            this.SpeciesDog_rbtn.Size = new System.Drawing.Size(45, 17);
            this.SpeciesDog_rbtn.TabIndex = 0;
            this.SpeciesDog_rbtn.TabStop = true;
            this.SpeciesDog_rbtn.Text = "Dog";
            this.SpeciesDog_rbtn.UseVisualStyleBackColor = true;
            this.SpeciesDog_rbtn.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // SpeciesCat_rbtn
            // 
            this.SpeciesCat_rbtn.AutoSize = true;
            this.SpeciesCat_rbtn.Location = new System.Drawing.Point(0, 22);
            this.SpeciesCat_rbtn.Name = "SpeciesCat_rbtn";
            this.SpeciesCat_rbtn.Size = new System.Drawing.Size(41, 17);
            this.SpeciesCat_rbtn.TabIndex = 1;
            this.SpeciesCat_rbtn.TabStop = true;
            this.SpeciesCat_rbtn.Text = "Cat";
            this.SpeciesCat_rbtn.UseVisualStyleBackColor = true;
            this.SpeciesCat_rbtn.CheckedChanged += new System.EventHandler(this.SpeciesCat_rbtn_CheckedChanged);
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(80, 3);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(138, 20);
            this.nameTextBox.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(5, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 26);
            this.label2.TabIndex = 7;
            this.label2.Text = "If un-named, \r\nleave blank";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Species";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "Gender";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(37, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Age";
            // 
            // Age_lstbx
            // 
            this.Age_lstbx.FormattingEnabled = true;
            this.Age_lstbx.Items.AddRange(new object[] {
            "Unsure",
            "0-1",
            "1-3",
            "4-6",
            "7-10",
            "10+"});
            this.Age_lstbx.Location = new System.Drawing.Point(79, 197);
            this.Age_lstbx.Name = "Age_lstbx";
            this.Age_lstbx.Size = new System.Drawing.Size(62, 82);
            this.Age_lstbx.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(36, 129);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "Size";
            // 
            // SizeXS_rbtn
            // 
            this.SizeXS_rbtn.AutoSize = true;
            this.SizeXS_rbtn.Location = new System.Drawing.Point(0, -1);
            this.SizeXS_rbtn.Name = "SizeXS_rbtn";
            this.SizeXS_rbtn.Size = new System.Drawing.Size(106, 17);
            this.SizeXS_rbtn.TabIndex = 7;
            this.SizeXS_rbtn.TabStop = true;
            this.SizeXS_rbtn.Text = "X-Small (1-10 lbs)";
            this.SizeXS_rbtn.UseVisualStyleBackColor = true;
            // 
            // SizeM_rbtn
            // 
            this.SizeM_rbtn.AutoSize = true;
            this.SizeM_rbtn.Location = new System.Drawing.Point(108, -1);
            this.SizeM_rbtn.Name = "SizeM_rbtn";
            this.SizeM_rbtn.Size = new System.Drawing.Size(114, 17);
            this.SizeM_rbtn.TabIndex = 9;
            this.SizeM_rbtn.TabStop = true;
            this.SizeM_rbtn.Text = "Medium (20-40 lbs)";
            this.SizeM_rbtn.UseVisualStyleBackColor = true;
            // 
            // SizeS_rbtn
            // 
            this.SizeS_rbtn.AutoSize = true;
            this.SizeS_rbtn.Location = new System.Drawing.Point(0, 23);
            this.SizeS_rbtn.Name = "SizeS_rbtn";
            this.SizeS_rbtn.Size = new System.Drawing.Size(102, 17);
            this.SizeS_rbtn.TabIndex = 8;
            this.SizeS_rbtn.TabStop = true;
            this.SizeS_rbtn.Text = "Small (11-20 lbs)";
            this.SizeS_rbtn.UseVisualStyleBackColor = true;
            // 
            // SizeL_rbtn
            // 
            this.SizeL_rbtn.AutoSize = true;
            this.SizeL_rbtn.Location = new System.Drawing.Point(108, 23);
            this.SizeL_rbtn.Name = "SizeL_rbtn";
            this.SizeL_rbtn.Size = new System.Drawing.Size(95, 17);
            this.SizeL_rbtn.TabIndex = 10;
            this.SizeL_rbtn.TabStop = true;
            this.SizeL_rbtn.Text = "Large (41+ lbs)";
            this.SizeL_rbtn.UseVisualStyleBackColor = true;
            // 
            // SubmitRegistration_btn
            // 
            this.SubmitRegistration_btn.Location = new System.Drawing.Point(313, 392);
            this.SubmitRegistration_btn.Name = "SubmitRegistration_btn";
            this.SubmitRegistration_btn.Size = new System.Drawing.Size(75, 23);
            this.SubmitRegistration_btn.TabIndex = 19;
            this.SubmitRegistration_btn.Text = "Submit";
            this.SubmitRegistration_btn.UseVisualStyleBackColor = true;
            this.SubmitRegistration_btn.Click += new System.EventHandler(this.SubmitRegistration_btn_Click);
            // 
            // ClearRegistration_btn
            // 
            this.ClearRegistration_btn.Location = new System.Drawing.Point(220, 392);
            this.ClearRegistration_btn.Name = "ClearRegistration_btn";
            this.ClearRegistration_btn.Size = new System.Drawing.Size(75, 23);
            this.ClearRegistration_btn.TabIndex = 20;
            this.ClearRegistration_btn.Text = "Clear";
            this.ClearRegistration_btn.UseVisualStyleBackColor = true;
            this.ClearRegistration_btn.Click += new System.EventHandler(this.ClearRegistration_Btn_Click);
            // 
            // Special_pnl
            // 
            this.Special_pnl.Controls.Add(this.SpeciesDog_rbtn);
            this.Special_pnl.Controls.Add(this.SpeciesCat_rbtn);
            this.Special_pnl.Location = new System.Drawing.Point(91, 32);
            this.Special_pnl.Name = "Special_pnl";
            this.Special_pnl.Size = new System.Drawing.Size(80, 64);
            this.Special_pnl.TabIndex = 21;
            // 
            // GenderM_rbtn
            // 
            this.GenderM_rbtn.AutoSize = true;
            this.GenderM_rbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.GenderM_rbtn.Location = new System.Drawing.Point(0, -1);
            this.GenderM_rbtn.Name = "GenderM_rbtn";
            this.GenderM_rbtn.Size = new System.Drawing.Size(48, 17);
            this.GenderM_rbtn.TabIndex = 3;
            this.GenderM_rbtn.TabStop = true;
            this.GenderM_rbtn.Text = "Male";
            this.GenderM_rbtn.UseVisualStyleBackColor = true;
            // 
            // GenderF_rbtn
            // 
            this.GenderF_rbtn.AutoSize = true;
            this.GenderF_rbtn.Location = new System.Drawing.Point(107, 0);
            this.GenderF_rbtn.Name = "GenderF_rbtn";
            this.GenderF_rbtn.Size = new System.Drawing.Size(59, 17);
            this.GenderF_rbtn.TabIndex = 4;
            this.GenderF_rbtn.TabStop = true;
            this.GenderF_rbtn.Text = "Female";
            this.GenderF_rbtn.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.GenderF_rbtn);
            this.panel2.Controls.Add(this.GenderM_rbtn);
            this.panel2.Location = new System.Drawing.Point(80, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(169, 41);
            this.panel2.TabIndex = 22;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.SizeL_rbtn);
            this.panel3.Controls.Add(this.SizeS_rbtn);
            this.panel3.Controls.Add(this.SizeM_rbtn);
            this.panel3.Controls.Add(this.SizeXS_rbtn);
            this.panel3.Location = new System.Drawing.Point(80, 129);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(222, 49);
            this.panel3.TabIndex = 23;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.Hypoallergenic_btn);
            this.panel4.Controls.Add(this.LongHair_rbtn);
            this.panel4.Controls.Add(this.MedHair_rbtn);
            this.panel4.Controls.Add(this.ShortHair_rbtn);
            this.panel4.Location = new System.Drawing.Point(434, 58);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(215, 46);
            this.panel4.TabIndex = 23;
            // 
            // Hypoallergenic_btn
            // 
            this.Hypoallergenic_btn.AutoSize = true;
            this.Hypoallergenic_btn.Location = new System.Drawing.Point(118, 24);
            this.Hypoallergenic_btn.Name = "Hypoallergenic_btn";
            this.Hypoallergenic_btn.Size = new System.Drawing.Size(95, 17);
            this.Hypoallergenic_btn.TabIndex = 6;
            this.Hypoallergenic_btn.TabStop = true;
            this.Hypoallergenic_btn.Text = "Hypoallergenic";
            this.Hypoallergenic_btn.UseVisualStyleBackColor = true;
            // 
            // LongHair_rbtn
            // 
            this.LongHair_rbtn.AutoSize = true;
            this.LongHair_rbtn.Location = new System.Drawing.Point(118, -1);
            this.LongHair_rbtn.Name = "LongHair_rbtn";
            this.LongHair_rbtn.Size = new System.Drawing.Size(71, 17);
            this.LongHair_rbtn.TabIndex = 5;
            this.LongHair_rbtn.TabStop = true;
            this.LongHair_rbtn.Text = "Long-Hair";
            this.LongHair_rbtn.UseVisualStyleBackColor = true;
            // 
            // MedHair_rbtn
            // 
            this.MedHair_rbtn.AutoSize = true;
            this.MedHair_rbtn.Location = new System.Drawing.Point(0, 24);
            this.MedHair_rbtn.Name = "MedHair_rbtn";
            this.MedHair_rbtn.Size = new System.Drawing.Size(84, 17);
            this.MedHair_rbtn.TabIndex = 4;
            this.MedHair_rbtn.TabStop = true;
            this.MedHair_rbtn.Text = "Meduim-Hair";
            this.MedHair_rbtn.UseVisualStyleBackColor = true;
            this.MedHair_rbtn.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // ShortHair_rbtn
            // 
            this.ShortHair_rbtn.AutoSize = true;
            this.ShortHair_rbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ShortHair_rbtn.Location = new System.Drawing.Point(0, 0);
            this.ShortHair_rbtn.Name = "ShortHair_rbtn";
            this.ShortHair_rbtn.Size = new System.Drawing.Size(72, 17);
            this.ShortHair_rbtn.TabIndex = 3;
            this.ShortHair_rbtn.TabStop = true;
            this.ShortHair_rbtn.Text = "Short-Hair";
            this.ShortHair_rbtn.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(351, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 32);
            this.label7.TabIndex = 24;
            this.label7.Text = "Fur Type/\r\nLength";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(323, 128);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 16);
            this.label12.TabIndex = 31;
            this.label12.Text = "Temperament";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.TemperamentMature_ckbx);
            this.panel5.Controls.Add(this.TemperamentSpecialCare_ckbx);
            this.panel5.Controls.Add(this.TemperamentOtherPets_ckbx);
            this.panel5.Controls.Add(this.TemperamentKids_ckbx);
            this.panel5.Location = new System.Drawing.Point(435, 129);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(212, 58);
            this.panel5.TabIndex = 23;
            // 
            // TemperamentMature_ckbx
            // 
            this.TemperamentMature_ckbx.AutoSize = true;
            this.TemperamentMature_ckbx.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.TemperamentMature_ckbx.Location = new System.Drawing.Point(104, -1);
            this.TemperamentMature_ckbx.Name = "TemperamentMature_ckbx";
            this.TemperamentMature_ckbx.Size = new System.Drawing.Size(103, 17);
            this.TemperamentMature_ckbx.TabIndex = 3;
            this.TemperamentMature_ckbx.Text = "Mature / Mellow";
            this.TemperamentMature_ckbx.UseVisualStyleBackColor = true;
            // 
            // TemperamentSpecialCare_ckbx
            // 
            this.TemperamentSpecialCare_ckbx.AutoSize = true;
            this.TemperamentSpecialCare_ckbx.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.TemperamentSpecialCare_ckbx.Location = new System.Drawing.Point(104, 28);
            this.TemperamentSpecialCare_ckbx.Name = "TemperamentSpecialCare_ckbx";
            this.TemperamentSpecialCare_ckbx.Size = new System.Drawing.Size(97, 30);
            this.TemperamentSpecialCare_ckbx.TabIndex = 2;
            this.TemperamentSpecialCare_ckbx.Text = "Special Care/\r\nMedical Needs\r\n";
            this.TemperamentSpecialCare_ckbx.UseVisualStyleBackColor = true;
            // 
            // TemperamentOtherPets_ckbx
            // 
            this.TemperamentOtherPets_ckbx.AutoSize = true;
            this.TemperamentOtherPets_ckbx.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.TemperamentOtherPets_ckbx.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.TemperamentOtherPets_ckbx.Location = new System.Drawing.Point(0, 28);
            this.TemperamentOtherPets_ckbx.Name = "TemperamentOtherPets_ckbx";
            this.TemperamentOtherPets_ckbx.Size = new System.Drawing.Size(74, 30);
            this.TemperamentOtherPets_ckbx.TabIndex = 1;
            this.TemperamentOtherPets_ckbx.Text = "Good with\r\nother pets";
            this.TemperamentOtherPets_ckbx.UseVisualStyleBackColor = true;
            // 
            // TemperamentKids_ckbx
            // 
            this.TemperamentKids_ckbx.AutoSize = true;
            this.TemperamentKids_ckbx.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.TemperamentKids_ckbx.Location = new System.Drawing.Point(0, -1);
            this.TemperamentKids_ckbx.Name = "TemperamentKids_ckbx";
            this.TemperamentKids_ckbx.Size = new System.Drawing.Size(97, 17);
            this.TemperamentKids_ckbx.TabIndex = 0;
            this.TemperamentKids_ckbx.Text = "Good with Kids";
            this.TemperamentKids_ckbx.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(298, 197);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(123, 16);
            this.label13.TabIndex = 32;
            this.label13.Text = "Additional Notes";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(224, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(209, 58);
            this.label14.TabIndex = 34;
            this.label14.Text = "Paw Pals \r\nAdoption Agency";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(276, 65);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(103, 16);
            this.label15.TabIndex = 35;
            this.label15.Text = "Pet Registration";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PetProperties_pnl
            // 
            this.PetProperties_pnl.Controls.Add(this.LogOutput_txtbx);
            this.PetProperties_pnl.Controls.Add(this.Notes_txtbx);
            this.PetProperties_pnl.Controls.Add(this.label8);
            this.PetProperties_pnl.Controls.Add(this.BreedorColor_txtbx);
            this.PetProperties_pnl.Controls.Add(this.panel4);
            this.PetProperties_pnl.Controls.Add(this.label7);
            this.PetProperties_pnl.Controls.Add(this.label13);
            this.PetProperties_pnl.Controls.Add(this.panel5);
            this.PetProperties_pnl.Controls.Add(this.label12);
            this.PetProperties_pnl.Controls.Add(this.panel3);
            this.PetProperties_pnl.Controls.Add(this.panel2);
            this.PetProperties_pnl.Controls.Add(this.label6);
            this.PetProperties_pnl.Controls.Add(this.Age_lstbx);
            this.PetProperties_pnl.Controls.Add(this.label5);
            this.PetProperties_pnl.Controls.Add(this.label4);
            this.PetProperties_pnl.Controls.Add(this.label2);
            this.PetProperties_pnl.Controls.Add(this.label1);
            this.PetProperties_pnl.Controls.Add(this.nameTextBox);
            this.PetProperties_pnl.Location = new System.Drawing.Point(12, 99);
            this.PetProperties_pnl.Name = "PetProperties_pnl";
            this.PetProperties_pnl.Size = new System.Drawing.Size(652, 282);
            this.PetProperties_pnl.TabIndex = 0;
            this.PetProperties_pnl.Visible = false;
            // 
            // Notes_txtbx
            // 
            this.Notes_txtbx.Location = new System.Drawing.Point(431, 197);
            this.Notes_txtbx.MaxLength = 25;
            this.Notes_txtbx.Multiline = true;
            this.Notes_txtbx.Name = "Notes_txtbx";
            this.Notes_txtbx.Size = new System.Drawing.Size(138, 27);
            this.Notes_txtbx.TabIndex = 33;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label8.Location = new System.Drawing.Point(352, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 32);
            this.label8.TabIndex = 25;
            this.label8.Text = "Breed/\r\nFur Color";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // BreedorColor_txtbx
            // 
            this.BreedorColor_txtbx.Location = new System.Drawing.Point(431, 2);
            this.BreedorColor_txtbx.MaxLength = 15;
            this.BreedorColor_txtbx.Name = "BreedorColor_txtbx";
            this.BreedorColor_txtbx.Size = new System.Drawing.Size(138, 20);
            this.BreedorColor_txtbx.TabIndex = 26;
            // 
            // Cat_img
            // 
            this.Cat_img.Image = global::PawPalsAdoptions_SC.Properties.Resources._218_2182558_black_cat_clipart_transparent_silhouette_of_cat_png;
            this.Cat_img.Location = new System.Drawing.Point(465, 3);
            this.Cat_img.Name = "Cat_img";
            this.Cat_img.Size = new System.Drawing.Size(95, 90);
            this.Cat_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Cat_img.TabIndex = 38;
            this.Cat_img.TabStop = false;
            this.Cat_img.Visible = false;
            // 
            // Dog_img
            // 
            this.Dog_img.Image = global::PawPalsAdoptions_SC.Properties.Resources.Doggie;
            this.Dog_img.Location = new System.Drawing.Point(447, 6);
            this.Dog_img.Name = "Dog_img";
            this.Dog_img.Size = new System.Drawing.Size(113, 89);
            this.Dog_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Dog_img.TabIndex = 18;
            this.Dog_img.TabStop = false;
            this.Dog_img.Visible = false;
            // 
            // LogOutput_txtbx
            // 
            this.LogOutput_txtbx.AcceptsReturn = true;
            this.LogOutput_txtbx.Location = new System.Drawing.Point(303, 230);
            this.LogOutput_txtbx.Multiline = true;
            this.LogOutput_txtbx.Name = "LogOutput_txtbx";
            this.LogOutput_txtbx.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.LogOutput_txtbx.Size = new System.Drawing.Size(349, 52);
            this.LogOutput_txtbx.TabIndex = 35;
            // 
            // RegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 427);
            this.Controls.Add(this.Cat_img);
            this.Controls.Add(this.Dog_img);
            this.Controls.Add(this.PetProperties_pnl);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.Special_pnl);
            this.Controls.Add(this.ClearRegistration_btn);
            this.Controls.Add(this.SubmitRegistration_btn);
            this.Controls.Add(this.label3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RegisterForm";
            this.Text = "Pet Registration Form";
            this.Load += new System.EventHandler(this.RegisterForm_Load);
            this.Special_pnl.ResumeLayout(false);
            this.Special_pnl.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.PetProperties_pnl.ResumeLayout(false);
            this.PetProperties_pnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Cat_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dog_img)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton SpeciesDog_rbtn;
        private System.Windows.Forms.RadioButton SpeciesCat_rbtn;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox Age_lstbx;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton SizeXS_rbtn;
        private System.Windows.Forms.RadioButton SizeM_rbtn;
        private System.Windows.Forms.RadioButton SizeS_rbtn;
        private System.Windows.Forms.RadioButton SizeL_rbtn;
        private System.Windows.Forms.PictureBox Dog_img;
        private System.Windows.Forms.Button SubmitRegistration_btn;
        private System.Windows.Forms.Button ClearRegistration_btn;
        private System.Windows.Forms.Panel Special_pnl;
        private System.Windows.Forms.RadioButton GenderM_rbtn;
        private System.Windows.Forms.RadioButton GenderF_rbtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton LongHair_rbtn;
        private System.Windows.Forms.RadioButton MedHair_rbtn;
        private System.Windows.Forms.RadioButton ShortHair_rbtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.CheckBox TemperamentMature_ckbx;
        private System.Windows.Forms.CheckBox TemperamentSpecialCare_ckbx;
        private System.Windows.Forms.CheckBox TemperamentOtherPets_ckbx;
        private System.Windows.Forms.CheckBox TemperamentKids_ckbx;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel PetProperties_pnl;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox BreedorColor_txtbx;
        private System.Windows.Forms.PictureBox Cat_img;
        private System.Windows.Forms.RadioButton Hypoallergenic_btn;
        private System.Windows.Forms.TextBox Notes_txtbx;
        private System.Windows.Forms.TextBox LogOutput_txtbx;
    }
}