﻿namespace PawPalsAdoptions_SC
{
    partial class Checkout_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Checkout_Form));
            this.youHaveSelected_lbl = new System.Windows.Forms.Label();
            this.petIdentifying_lbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Yes_rdbtn = new System.Windows.Forms.RadioButton();
            this.No_rdbtn = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Cat2_rdbtn = new System.Windows.Forms.RadioButton();
            this.Dog2_rdbtn = new System.Windows.Forms.RadioButton();
            this.PetFoodInput_txtbx = new System.Windows.Forms.TextBox();
            this.PetTreatInput_txtbx = new System.Windows.Forms.TextBox();
            this.PetFood_lbl = new System.Windows.Forms.Label();
            this.PetFoodQuantity_lbl = new System.Windows.Forms.Label();
            this.PetTreats_lbl = new System.Windows.Forms.Label();
            this.PetFoodFee_lbl = new System.Windows.Forms.Label();
            this.PetTreatsFee_lbl = new System.Windows.Forms.Label();
            this.PetBedFee_lbl = new System.Windows.Forms.Label();
            this.CollarFee_lbl = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Collar_lbl = new System.Windows.Forms.Label();
            this.PetBed_lbl = new System.Windows.Forms.Label();
            this.Collar_ckbx = new System.Windows.Forms.CheckBox();
            this.PetBed_ckbx = new System.Windows.Forms.CheckBox();
            this.CurrentTotal_lbl = new System.Windows.Forms.Label();
            this.CalculateTotal_lbl = new System.Windows.Forms.Label();
            this.Clear2_btn = new System.Windows.Forms.Button();
            this.Submit2_btn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Registration_pnl = new System.Windows.Forms.Panel();
            this.RegistrationDescription_lbl = new System.Windows.Forms.Label();
            this.PetRegistrationFee_lbl = new System.Windows.Forms.Label();
            this.Species2_lbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Dog_img = new System.Windows.Forms.PictureBox();
            this.Cat_img = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.Registration_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dog_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cat_img)).BeginInit();
            this.SuspendLayout();
            // 
            // youHaveSelected_lbl
            // 
            this.youHaveSelected_lbl.AutoSize = true;
            this.youHaveSelected_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.youHaveSelected_lbl.Location = new System.Drawing.Point(3, 1);
            this.youHaveSelected_lbl.Name = "youHaveSelected_lbl";
            this.youHaveSelected_lbl.Size = new System.Drawing.Size(124, 13);
            this.youHaveSelected_lbl.TabIndex = 0;
            this.youHaveSelected_lbl.Text = "Your selected pet is:";
            this.youHaveSelected_lbl.Click += new System.EventHandler(this.youHaveSelected_lbl_Click);
            // 
            // petIdentifying_lbl
            // 
            this.petIdentifying_lbl.AutoSize = true;
            this.petIdentifying_lbl.Location = new System.Drawing.Point(130, 1);
            this.petIdentifying_lbl.Name = "petIdentifying_lbl";
            this.petIdentifying_lbl.Size = new System.Drawing.Size(172, 13);
            this.petIdentifying_lbl.TabIndex = 1;
            this.petIdentifying_lbl.Text = "{Name}, a {Breed/Color} {Species}";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(289, 52);
            this.label1.TabIndex = 5;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // Yes_rdbtn
            // 
            this.Yes_rdbtn.AutoSize = true;
            this.Yes_rdbtn.Location = new System.Drawing.Point(3, 0);
            this.Yes_rdbtn.Name = "Yes_rdbtn";
            this.Yes_rdbtn.Size = new System.Drawing.Size(43, 17);
            this.Yes_rdbtn.TabIndex = 6;
            this.Yes_rdbtn.Text = "Yes";
            this.Yes_rdbtn.UseVisualStyleBackColor = true;
            this.Yes_rdbtn.CheckedChanged += new System.EventHandler(this.Yes_rdbtn_CheckedChanged);
            // 
            // No_rdbtn
            // 
            this.No_rdbtn.AutoSize = true;
            this.No_rdbtn.Location = new System.Drawing.Point(86, 0);
            this.No_rdbtn.Name = "No_rdbtn";
            this.No_rdbtn.Size = new System.Drawing.Size(39, 17);
            this.No_rdbtn.TabIndex = 7;
            this.No_rdbtn.Text = "No";
            this.No_rdbtn.UseVisualStyleBackColor = true;
            this.No_rdbtn.CheckedChanged += new System.EventHandler(this.No_rdbtn_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(271, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Would you like to proceed with adopting {Name} today?\r\n";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.petIdentifying_lbl);
            this.panel1.Controls.Add(this.youHaveSelected_lbl);
            this.panel1.Location = new System.Drawing.Point(150, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(305, 143);
            this.panel1.TabIndex = 9;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.No_rdbtn);
            this.panel3.Controls.Add(this.Yes_rdbtn);
            this.panel3.Location = new System.Drawing.Point(82, 102);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(125, 25);
            this.panel3.TabIndex = 46;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.Cat2_rdbtn);
            this.panel2.Controls.Add(this.Dog2_rdbtn);
            this.panel2.Location = new System.Drawing.Point(12, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(132, 92);
            this.panel2.TabIndex = 45;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 26);
            this.label4.TabIndex = 64;
            this.label4.Text = "Is the customer shopping \r\nfor a dog, or a cat?";
            // 
            // Cat2_rdbtn
            // 
            this.Cat2_rdbtn.AutoSize = true;
            this.Cat2_rdbtn.Location = new System.Drawing.Point(6, 64);
            this.Cat2_rdbtn.Name = "Cat2_rdbtn";
            this.Cat2_rdbtn.Size = new System.Drawing.Size(41, 17);
            this.Cat2_rdbtn.TabIndex = 44;
            this.Cat2_rdbtn.Text = "Cat";
            this.Cat2_rdbtn.UseVisualStyleBackColor = true;
            this.Cat2_rdbtn.CheckedChanged += new System.EventHandler(this.Cat2_rdbtn_CheckedChanged);
            // 
            // Dog2_rdbtn
            // 
            this.Dog2_rdbtn.AutoSize = true;
            this.Dog2_rdbtn.Location = new System.Drawing.Point(6, 41);
            this.Dog2_rdbtn.Name = "Dog2_rdbtn";
            this.Dog2_rdbtn.Size = new System.Drawing.Size(45, 17);
            this.Dog2_rdbtn.TabIndex = 43;
            this.Dog2_rdbtn.Text = "Dog";
            this.Dog2_rdbtn.UseVisualStyleBackColor = true;
            this.Dog2_rdbtn.CheckedChanged += new System.EventHandler(this.Dog2_rdbtn_CheckedChanged);
            // 
            // PetFoodInput_txtbx
            // 
            this.PetFoodInput_txtbx.Location = new System.Drawing.Point(148, 74);
            this.PetFoodInput_txtbx.Name = "PetFoodInput_txtbx";
            this.PetFoodInput_txtbx.Size = new System.Drawing.Size(32, 20);
            this.PetFoodInput_txtbx.TabIndex = 13;
            // 
            // PetTreatInput_txtbx
            // 
            this.PetTreatInput_txtbx.Location = new System.Drawing.Point(148, 118);
            this.PetTreatInput_txtbx.Name = "PetTreatInput_txtbx";
            this.PetTreatInput_txtbx.Size = new System.Drawing.Size(32, 20);
            this.PetTreatInput_txtbx.TabIndex = 14;
            // 
            // PetFood_lbl
            // 
            this.PetFood_lbl.AutoSize = true;
            this.PetFood_lbl.Location = new System.Drawing.Point(12, 73);
            this.PetFood_lbl.Name = "PetFood_lbl";
            this.PetFood_lbl.Size = new System.Drawing.Size(50, 13);
            this.PetFood_lbl.TabIndex = 42;
            this.PetFood_lbl.Text = "Pet Food";
            // 
            // PetFoodQuantity_lbl
            // 
            this.PetFoodQuantity_lbl.AutoSize = true;
            this.PetFoodQuantity_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PetFoodQuantity_lbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.PetFoodQuantity_lbl.Location = new System.Drawing.Point(20, 86);
            this.PetFoodQuantity_lbl.Name = "PetFoodQuantity_lbl";
            this.PetFoodQuantity_lbl.Size = new System.Drawing.Size(46, 13);
            this.PetFoodQuantity_lbl.TabIndex = 43;
            this.PetFoodQuantity_lbl.Text = "2 lb Bag";
            this.PetFoodQuantity_lbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // PetTreats_lbl
            // 
            this.PetTreats_lbl.AutoSize = true;
            this.PetTreats_lbl.Location = new System.Drawing.Point(6, 121);
            this.PetTreats_lbl.Name = "PetTreats_lbl";
            this.PetTreats_lbl.Size = new System.Drawing.Size(56, 13);
            this.PetTreats_lbl.TabIndex = 44;
            this.PetTreats_lbl.Text = "Pet Treats";
            // 
            // PetFoodFee_lbl
            // 
            this.PetFoodFee_lbl.AutoSize = true;
            this.PetFoodFee_lbl.Location = new System.Drawing.Point(93, 77);
            this.PetFoodFee_lbl.Name = "PetFoodFee_lbl";
            this.PetFoodFee_lbl.Size = new System.Drawing.Size(40, 13);
            this.PetFoodFee_lbl.TabIndex = 45;
            this.PetFoodFee_lbl.Text = "$25.50";
            // 
            // PetTreatsFee_lbl
            // 
            this.PetTreatsFee_lbl.AutoSize = true;
            this.PetTreatsFee_lbl.Location = new System.Drawing.Point(99, 121);
            this.PetTreatsFee_lbl.Name = "PetTreatsFee_lbl";
            this.PetTreatsFee_lbl.Size = new System.Drawing.Size(34, 13);
            this.PetTreatsFee_lbl.TabIndex = 46;
            this.PetTreatsFee_lbl.Text = "$9.75";
            // 
            // PetBedFee_lbl
            // 
            this.PetBedFee_lbl.AutoSize = true;
            this.PetBedFee_lbl.Location = new System.Drawing.Point(286, 77);
            this.PetBedFee_lbl.Name = "PetBedFee_lbl";
            this.PetBedFee_lbl.Size = new System.Drawing.Size(40, 13);
            this.PetBedFee_lbl.TabIndex = 53;
            this.PetBedFee_lbl.Text = "$42.00";
            // 
            // CollarFee_lbl
            // 
            this.CollarFee_lbl.AutoSize = true;
            this.CollarFee_lbl.Location = new System.Drawing.Point(286, 19);
            this.CollarFee_lbl.Name = "CollarFee_lbl";
            this.CollarFee_lbl.Size = new System.Drawing.Size(40, 13);
            this.CollarFee_lbl.TabIndex = 52;
            this.CollarFee_lbl.Text = "$12.50";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 543);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 13);
            this.label11.TabIndex = 51;
            // 
            // Collar_lbl
            // 
            this.Collar_lbl.AutoSize = true;
            this.Collar_lbl.Location = new System.Drawing.Point(210, 19);
            this.Collar_lbl.Name = "Collar_lbl";
            this.Collar_lbl.Size = new System.Drawing.Size(57, 26);
            this.Collar_lbl.TabIndex = 49;
            this.Collar_lbl.Text = "Collar and \r\nLeash";
            this.Collar_lbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // PetBed_lbl
            // 
            this.PetBed_lbl.AutoSize = true;
            this.PetBed_lbl.Location = new System.Drawing.Point(218, 77);
            this.PetBed_lbl.Name = "PetBed_lbl";
            this.PetBed_lbl.Size = new System.Drawing.Size(45, 13);
            this.PetBed_lbl.TabIndex = 54;
            this.PetBed_lbl.Text = "Pet Bed";
            this.PetBed_lbl.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Collar_ckbx
            // 
            this.Collar_ckbx.AutoSize = true;
            this.Collar_ckbx.Location = new System.Drawing.Point(360, 20);
            this.Collar_ckbx.Name = "Collar_ckbx";
            this.Collar_ckbx.Size = new System.Drawing.Size(15, 14);
            this.Collar_ckbx.TabIndex = 55;
            this.Collar_ckbx.UseVisualStyleBackColor = true;
            // 
            // PetBed_ckbx
            // 
            this.PetBed_ckbx.AutoSize = true;
            this.PetBed_ckbx.Location = new System.Drawing.Point(360, 74);
            this.PetBed_ckbx.Name = "PetBed_ckbx";
            this.PetBed_ckbx.Size = new System.Drawing.Size(15, 14);
            this.PetBed_ckbx.TabIndex = 56;
            this.PetBed_ckbx.UseVisualStyleBackColor = true;
            // 
            // CurrentTotal_lbl
            // 
            this.CurrentTotal_lbl.AutoSize = true;
            this.CurrentTotal_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentTotal_lbl.Location = new System.Drawing.Point(236, 118);
            this.CurrentTotal_lbl.Name = "CurrentTotal_lbl";
            this.CurrentTotal_lbl.Size = new System.Drawing.Size(69, 20);
            this.CurrentTotal_lbl.TabIndex = 59;
            this.CurrentTotal_lbl.Text = "TOTAL:";
            // 
            // CalculateTotal_lbl
            // 
            this.CalculateTotal_lbl.AutoSize = true;
            this.CalculateTotal_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalculateTotal_lbl.Location = new System.Drawing.Point(307, 118);
            this.CalculateTotal_lbl.Name = "CalculateTotal_lbl";
            this.CalculateTotal_lbl.Size = new System.Drawing.Size(0, 20);
            this.CalculateTotal_lbl.TabIndex = 60;
            // 
            // Clear2_btn
            // 
            this.Clear2_btn.Location = new System.Drawing.Point(150, 316);
            this.Clear2_btn.Name = "Clear2_btn";
            this.Clear2_btn.Size = new System.Drawing.Size(75, 23);
            this.Clear2_btn.TabIndex = 61;
            this.Clear2_btn.Text = "Clear";
            this.Clear2_btn.UseVisualStyleBackColor = true;
            // 
            // Submit2_btn
            // 
            this.Submit2_btn.Location = new System.Drawing.Point(244, 316);
            this.Submit2_btn.Name = "Submit2_btn";
            this.Submit2_btn.Size = new System.Drawing.Size(75, 23);
            this.Submit2_btn.TabIndex = 62;
            this.Submit2_btn.Text = "Submit";
            this.Submit2_btn.UseVisualStyleBackColor = true;
            this.Submit2_btn.Click += new System.EventHandler(this.Submit2_btn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Registration_pnl);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Dog_img);
            this.groupBox1.Controls.Add(this.CalculateTotal_lbl);
            this.groupBox1.Controls.Add(this.Cat_img);
            this.groupBox1.Controls.Add(this.CurrentTotal_lbl);
            this.groupBox1.Controls.Add(this.PetBed_ckbx);
            this.groupBox1.Controls.Add(this.Collar_ckbx);
            this.groupBox1.Controls.Add(this.PetBed_lbl);
            this.groupBox1.Controls.Add(this.PetBedFee_lbl);
            this.groupBox1.Controls.Add(this.CollarFee_lbl);
            this.groupBox1.Controls.Add(this.Collar_lbl);
            this.groupBox1.Controls.Add(this.PetTreatsFee_lbl);
            this.groupBox1.Controls.Add(this.PetFoodFee_lbl);
            this.groupBox1.Controls.Add(this.PetTreats_lbl);
            this.groupBox1.Controls.Add(this.PetFoodQuantity_lbl);
            this.groupBox1.Controls.Add(this.PetFood_lbl);
            this.groupBox1.Controls.Add(this.PetTreatInput_txtbx);
            this.groupBox1.Controls.Add(this.PetFoodInput_txtbx);
            this.groupBox1.Location = new System.Drawing.Point(31, 161);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(424, 152);
            this.groupBox1.TabIndex = 63;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Checkout Items";
            // 
            // Registration_pnl
            // 
            this.Registration_pnl.Controls.Add(this.RegistrationDescription_lbl);
            this.Registration_pnl.Controls.Add(this.PetRegistrationFee_lbl);
            this.Registration_pnl.Controls.Add(this.Species2_lbl);
            this.Registration_pnl.Location = new System.Drawing.Point(3, 16);
            this.Registration_pnl.Name = "Registration_pnl";
            this.Registration_pnl.Size = new System.Drawing.Size(138, 54);
            this.Registration_pnl.TabIndex = 62;
            this.Registration_pnl.Visible = false;
            // 
            // RegistrationDescription_lbl
            // 
            this.RegistrationDescription_lbl.AutoSize = true;
            this.RegistrationDescription_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegistrationDescription_lbl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.RegistrationDescription_lbl.Location = new System.Drawing.Point(2, 16);
            this.RegistrationDescription_lbl.Name = "RegistrationDescription_lbl";
            this.RegistrationDescription_lbl.Size = new System.Drawing.Size(63, 26);
            this.RegistrationDescription_lbl.TabIndex = 58;
            this.RegistrationDescription_lbl.Text = "Registration\r\nFee";
            this.RegistrationDescription_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PetRegistrationFee_lbl
            // 
            this.PetRegistrationFee_lbl.AutoSize = true;
            this.PetRegistrationFee_lbl.Location = new System.Drawing.Point(84, 4);
            this.PetRegistrationFee_lbl.Name = "PetRegistrationFee_lbl";
            this.PetRegistrationFee_lbl.Size = new System.Drawing.Size(46, 13);
            this.PetRegistrationFee_lbl.TabIndex = 57;
            this.PetRegistrationFee_lbl.Text = "$150.00";
            // 
            // Species2_lbl
            // 
            this.Species2_lbl.AutoSize = true;
            this.Species2_lbl.Location = new System.Drawing.Point(-1, 3);
            this.Species2_lbl.Name = "Species2_lbl";
            this.Species2_lbl.Size = new System.Drawing.Size(69, 13);
            this.Species2_lbl.TabIndex = 41;
            this.Species2_lbl.Text = "Dog, {Name}";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(2, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 61;
            this.label3.Text = "Bag of treats";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Dog_img
            // 
            this.Dog_img.Image = global::PawPalsAdoptions_SC.Properties.Resources.Doggie;
            this.Dog_img.Location = new System.Drawing.Point(143, 10);
            this.Dog_img.Name = "Dog_img";
            this.Dog_img.Size = new System.Drawing.Size(41, 45);
            this.Dog_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Dog_img.TabIndex = 39;
            this.Dog_img.TabStop = false;
            this.Dog_img.Visible = false;
            // 
            // Cat_img
            // 
            this.Cat_img.Image = global::PawPalsAdoptions_SC.Properties.Resources._218_2182558_black_cat_clipart_transparent_silhouette_of_cat_png;
            this.Cat_img.Location = new System.Drawing.Point(142, 10);
            this.Cat_img.Name = "Cat_img";
            this.Cat_img.Size = new System.Drawing.Size(42, 40);
            this.Cat_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Cat_img.TabIndex = 40;
            this.Cat_img.TabStop = false;
            this.Cat_img.Visible = false;
            // 
            // Checkout_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 342);
            this.Controls.Add(this.Submit2_btn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Clear2_btn);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Checkout_Form";
            this.Text = "Checkout Form";
            this.Load += new System.EventHandler(this.CheckoutForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Registration_pnl.ResumeLayout(false);
            this.Registration_pnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dog_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cat_img)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label youHaveSelected_lbl;
        private System.Windows.Forms.Label petIdentifying_lbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton Yes_rdbtn;
        private System.Windows.Forms.RadioButton No_rdbtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox PetFoodInput_txtbx;
        private System.Windows.Forms.TextBox PetTreatInput_txtbx;
        private System.Windows.Forms.RadioButton Cat2_rdbtn;
        private System.Windows.Forms.RadioButton Dog2_rdbtn;
        private System.Windows.Forms.Label PetFood_lbl;
        private System.Windows.Forms.Label PetFoodQuantity_lbl;
        private System.Windows.Forms.Label PetTreats_lbl;
        private System.Windows.Forms.Label PetFoodFee_lbl;
        private System.Windows.Forms.Label PetTreatsFee_lbl;
        private System.Windows.Forms.Label PetBedFee_lbl;
        private System.Windows.Forms.Label CollarFee_lbl;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label Collar_lbl;
        private System.Windows.Forms.Label PetBed_lbl;
        private System.Windows.Forms.CheckBox Collar_ckbx;
        private System.Windows.Forms.CheckBox PetBed_ckbx;
        private System.Windows.Forms.Label CurrentTotal_lbl;
        private System.Windows.Forms.Label CalculateTotal_lbl;
        private System.Windows.Forms.Button Clear2_btn;
        private System.Windows.Forms.Button Submit2_btn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel Registration_pnl;
        private System.Windows.Forms.Label RegistrationDescription_lbl;
        private System.Windows.Forms.Label PetRegistrationFee_lbl;
        private System.Windows.Forms.Label Species2_lbl;
        private System.Windows.Forms.PictureBox Dog_img;
        private System.Windows.Forms.PictureBox Cat_img;
    }
}