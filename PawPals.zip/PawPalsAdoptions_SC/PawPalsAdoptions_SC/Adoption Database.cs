﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PawPalsAdoptions_SC
{
    public partial class AdoptionDatabase : Form
    {
        public AdoptionDatabase()
        {
            InitializeComponent();
        }

        public class PetData
        {
            public int PetID { get; set; }
            public string Species { get; set; }
            public string Name { get; set; }
            public string Gender { get; set; }
            public string PetSize { get; set; }
            public string Age { get; set; }
            public string Breed { get; set; }
            public string FurType { get; set; }
            public bool GoodwKids { get; set; }
            public bool GoodwOtherPets { get; set; }
            public bool MatureOrMellow { get; set; }
            public bool SpecialCare { get; set; }
            public string Remarks { get; set; }
            public bool Available { get; set; }
        }

        DataTable table = new DataTable();
        public static List<PetData> pd;
        public static int selectedPetID = 0;

        public void Adoption_Database_Load(object sender, EventArgs e)
        {


            //table.Columns.Add("Species", typeof(string));
            //table.Columns.Add("Name", typeof(string));
            //table.Columns.Add("Gender", typeof(string));
            //table.Columns.Add("Size", typeof(string));
            //table.Columns.Add("Age", typeof(string));
            //table.Columns.Add("Breed/Color", typeof(string));
            //table.Columns.Add("Fur Type", typeof(string));
            //table.Columns.Add("Good w/ Kids", typeof(bool));
            //table.Columns.Add("Good w/ Other Pets", typeof(bool));
            //table.Columns.Add("Mature/\nMellow", typeof(bool));
            //table.Columns.Add("Special Care/\nNeeds", typeof(bool));
            //table.Columns.Add("Remarks/Notes", typeof(string));
            //AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells
            //

            if (pd == null)
            {
                string[] lines = File.ReadAllLines(Path.GetDirectoryName(Application.ExecutablePath) + @"\PawPalsRegistry.txt");

                pd = new List<PetData>();
                int petId = 1001;
                foreach (var line in lines)
                {
                    string[] lineValue = line.Split(',');
                    pd.Add(new PetData
                    {
                        PetID = petId,
                        Species = lineValue[0].Trim(),
                        Name = lineValue[1].Trim(),
                        Gender = lineValue[2].Trim(),
                        PetSize = lineValue[3].Trim(),
                        Age = lineValue[4].Trim(),
                        Breed = lineValue[5].Trim(),
                        FurType = lineValue[6].Trim(),
                        GoodwKids = lineValue[7].Contains("True"),
                        GoodwOtherPets = lineValue[8].Contains("True"),
                        MatureOrMellow = lineValue[9].Contains("True"),
                        SpecialCare = lineValue[10].Contains("True"),
                        Remarks = lineValue[11].Trim(),
                        Available = lineValue[12].Contains("True")
                    });
                    petId++;
                }

                //Filter
                SearchRegistry_dt.DataSource = pd.OrderBy(x => x.PetID).ThenBy(x => x.Name);
                SearchRegistry_dt.AutoResizeColumns();
                SearchRegistry_dt.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;

            }

            //Code for when pet is adopted -- they are automatically removed from the filter.
            var selectedPet = pd.Where(x => x.PetID == selectedPetID).FirstOrDefault();
            if (selectedPet != null)
            {
                selectedPet.Available = false;
            }

            //string[] values;
            //SearchRegistry_dt.DataSource = table;
            //SearchRegistry_dt.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            //for (int i = 0; i < lines.Length; i++)
            //{
            //    values = lines[i].ToString().Split(',');
            //    string[] row = new string[values.Length];
            //    for (int j = 0; j < values.Length; j++)
            //    {
            //        row[j] = values[j].Trim();
            //    }
            //    table.Rows.Add(row);
            //}
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void DisplaySearch_btn_Click(object sender, EventArgs e)
        {
            var petData = pd;

            //Species Filter
            if (Dog_rdbtn.Checked == true || Cat_rdbtn.Checked == true)
            {
                var species = Dog_rdbtn.Checked == true ? "DOG" : "CAT";

               petData = petData.Where(x => x.Species.ToUpper() == species).ToList();
            }

            if (Male_rdbtn.Checked == true || Female_rdbtn.Checked == true)
            {
                var gender = Male_rdbtn.Checked == true ? "MALE" : "FEMALE";

                petData = petData.Where(x => x.Gender.ToUpper() == gender).ToList();
            }

            //Tempermant filter
            if (Kids_ckbx.Checked == true)
            {
                petData = petData.Where(x => x.GoodwKids == true).ToList();

            }
            if (Pets_ckbx.Checked == true)
            {
                petData = petData.Where(x => x.GoodwOtherPets == true).ToList();

            }
            if (Mature_ckbx.Checked == true)
            {
                petData = petData.Where(x => x.MatureOrMellow == true).ToList();

            }
            if (SpecialCare_ckbk.Checked == true)
            {
                petData = petData.Where(x => x.SpecialCare == true).ToList();

            }
            SearchRegistry_dt.DataSource = petData;

            //Gender Filter

            //BindingSource bs = new BindingSource();
            //bs.Clear();
            //bs.DataSource = SearchRegistry_dt.DataSource;

            /*string isDog, isMale;

            if (Dog_rdbtn.Checked == true)
            {
                isDog = "Dog";
            }
            else
            {
                isDog = "Cat";
            }

            if (Male_btn.Checked == true)
            {
                isMale = "Male";
            }
            else
            {
                isMale = "Female";
            }
            bs.Filter = SearchRegistry_dt.Columns[0].HeaderText.ToString() + " LIKE '%" + "Dog" + "%'";
            SearchRegistry_dt.DataSource = bs;
            bs.Filter = SearchRegistry_dt.Columns[2].HeaderText.ToString() + " = 'Male'";
            SearchRegistry_dt.DataSource = bs;*


            if (Dog_rdbtn.Checked == true)
            {
                bs.Filter = SearchRegistry_dt.Columns[0].HeaderText.ToString() + " = 'Dog'";
                bs.Filter = SearchRegistry_dt.Columns[2].HeaderText.ToString() + " = 'Male'";
                SearchRegistry_dt.DataSource = bs;
            }
            else
            {
                bs.Filter = SearchRegistry_dt.Columns[0].HeaderText.ToString() + " = 'Cat'";
                SearchRegistry_dt.DataSource = bs;
            }
            /*if (Male_rdbtn.Checked == true)
            {
                bs.Filter = SearchRegistry_dt.Columns[2].HeaderText.ToString() + "=" + "Male";
                SearchRegistry_dt.DataSource = bs;
            }
            else
            {
                bs.Filter = SearchRegistry_dt.Columns[2].HeaderText.ToString() + " LIKE '%" + "Female" + "%'";
                SearchRegistry_dt.DataSource = bs;
            }*/
        }

        private void Attempt2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Dog_rdbtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void RegisteryClear_btn_Click(object sender, EventArgs e)
        {
            Dog_rdbtn.Checked = false;
            Cat_rdbtn.Checked = false;
            Male_rdbtn.Checked = false;
            Female_rdbtn.Checked = false;
            Kids_ckbx.Checked = false;
            Pets_ckbx.Checked = false;
            Mature_ckbx.Checked = false;
            SpecialCare_ckbk.Checked = false;
            SearchRegistry_dt.ClearSelection();
        }

        private void AdoptSelected_btn_Click(object sender, EventArgs e)
        {
            SearchRegistry_dt.Rows.GetRowCount(DataGridViewElementStates.Selected);
            var petData = pd;
            //testLabel.Text = SearchRegistry_dt.pd[].Text;
        }
    }
}
