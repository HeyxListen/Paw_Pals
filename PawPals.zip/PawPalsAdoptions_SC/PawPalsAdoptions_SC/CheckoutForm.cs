﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PawPalsAdoptions_SC
{
    public partial class Checkout_Form : Form
    {
        public Checkout_Form()
        {
            InitializeComponent();
        }

        private void CheckoutForm_Load(object sender, EventArgs e)
        {

        }

        private void youHaveSelected_lbl_Click(object sender, EventArgs e)
        {

        }

        private void Yes_rdbtn_CheckedChanged(object sender, EventArgs e)
        {
            Registration_pnl.Visible = true;
        }

        private void Cat2_rdbtn_CheckedChanged(object sender, EventArgs e)
        {
            Dog_img.Visible = false;
            Cat_img.Visible = true;
            PetRegistrationFee_lbl.Text = "$120.00";
            Species2_lbl.Text = "Cat {Name}";
            Collar_lbl.Text = "Collar";
        }

        private void Dog2_rdbtn_CheckedChanged(object sender, EventArgs e)
        {
            Dog_img.Visible = true;
            Cat_img.Visible = false;
            Dog_img.Visible = true;
            Cat_img.Visible = false;
            PetRegistrationFee_lbl.Text = "$140.00";
            Species2_lbl.Text = "Dog {Name}";
            Collar_lbl.Text = "Collar and\nLeash";
        }

        private void No_rdbtn_CheckedChanged(object sender, EventArgs e)
        {
            Registration_pnl.Visible = false;
        }

        private void Submit2_btn_Click(object sender, EventArgs e)
        {
            CalculateTotal_lbl.Text = "";
            double total = 0, registrationFee = 0, petFood = 0, petTreats = 0, collar =0, petBed = 0;
            petFood = double.Parse(PetFoodInput_txtbx.Text);
            petTreats = double.Parse(PetFoodInput_txtbx.Text);
            if (Yes_rdbtn.Checked == true && Dog2_rdbtn.Checked == true)
            {
                registrationFee = 140.00;
            }
            else
            {
                if ((Yes_rdbtn.Checked == true && Cat2_rdbtn.Checked == true))
                {
                    registrationFee = 120.00;
                }
                else
                {
                    registrationFee = 0.00;
                }
            } 
            if (Collar_ckbx.Checked == true)
            {
                collar = 1;
            }
            else
            {
                collar = 0;
            }
            if (PetBed_ckbx.Checked == true)
            {
                petBed = 1;
            }
            else
            {
                petBed = 0;
            }
            petBed = double.Parse(PetFoodInput_txtbx.Text);
            total = (petFood * 25.50)+(petTreats*9.75)+(collar*12.50)+(petBed*42.00);
            //if (Dog2_rdbtn.Checked == true)
            //{
            //}
            CalculateTotal_lbl.Text = total.ToString("C");
        }
    }
}
