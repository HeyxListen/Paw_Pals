﻿namespace PawPalsAdoptions_SC
{
    partial class PawPals_MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PawPals_MainScreen));
            this.label1 = new System.Windows.Forms.Label();
            this.RegisterPet_btn = new System.Windows.Forms.Button();
            this.AdoptionDatabase_btn = new System.Windows.Forms.Button();
            this.CustomerCheckOut_btn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(56, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Adoption Agency";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // RegisterPet_btn
            // 
            this.RegisterPet_btn.Location = new System.Drawing.Point(62, 177);
            this.RegisterPet_btn.Name = "RegisterPet_btn";
            this.RegisterPet_btn.Size = new System.Drawing.Size(82, 34);
            this.RegisterPet_btn.TabIndex = 3;
            this.RegisterPet_btn.Text = "Register Pet";
            this.RegisterPet_btn.UseVisualStyleBackColor = true;
            this.RegisterPet_btn.Click += new System.EventHandler(this.RegisterPet_btn_Click);
            // 
            // AdoptionDatabase_btn
            // 
            this.AdoptionDatabase_btn.Location = new System.Drawing.Point(62, 217);
            this.AdoptionDatabase_btn.Name = "AdoptionDatabase_btn";
            this.AdoptionDatabase_btn.Size = new System.Drawing.Size(82, 34);
            this.AdoptionDatabase_btn.TabIndex = 5;
            this.AdoptionDatabase_btn.Text = "Adoption Database";
            this.AdoptionDatabase_btn.UseVisualStyleBackColor = true;
            this.AdoptionDatabase_btn.Click += new System.EventHandler(this.AdoptionDatabase_btn_Click);
            // 
            // CustomerCheckOut_btn
            // 
            this.CustomerCheckOut_btn.Location = new System.Drawing.Point(165, 195);
            this.CustomerCheckOut_btn.Name = "CustomerCheckOut_btn";
            this.CustomerCheckOut_btn.Size = new System.Drawing.Size(86, 34);
            this.CustomerCheckOut_btn.TabIndex = 7;
            this.CustomerCheckOut_btn.Text = "Customer Checkout";
            this.CustomerCheckOut_btn.UseVisualStyleBackColor = true;
            this.CustomerCheckOut_btn.Click += new System.EventHandler(this.CustomerCheckOut_btn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PawPalsAdoptions_SC.Properties.Resources.PawPalsTP2;
            this.pictureBox1.Location = new System.Drawing.Point(84, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(145, 136);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // PawPals_MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(319, 260);
            this.Controls.Add(this.CustomerCheckOut_btn);
            this.Controls.Add(this.AdoptionDatabase_btn);
            this.Controls.Add(this.RegisterPet_btn);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "PawPals_MainScreen";
            this.Text = "Paw Pals Adoption Agency";
            this.Load += new System.EventHandler(this.PawPals_MainScreen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button RegisterPet_btn;
        private System.Windows.Forms.Button AdoptionDatabase_btn;
        private System.Windows.Forms.Button CustomerCheckOut_btn;
    }
}

