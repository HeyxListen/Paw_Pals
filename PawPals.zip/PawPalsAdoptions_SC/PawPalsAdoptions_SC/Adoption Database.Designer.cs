﻿namespace PawPalsAdoptions_SC
{
    partial class AdoptionDatabase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdoptionDatabase));
            this.DisplaySearch_btn = new System.Windows.Forms.Button();
            this.SearchRegistry_dt = new System.Windows.Forms.DataGridView();
            this.Dog_rdbtn = new System.Windows.Forms.RadioButton();
            this.Cat_rdbtn = new System.Windows.Forms.RadioButton();
            this.SpecialCare_ckbk = new System.Windows.Forms.CheckBox();
            this.Mature_ckbx = new System.Windows.Forms.CheckBox();
            this.Pets_ckbx = new System.Windows.Forms.CheckBox();
            this.Kids_ckbx = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.RegisteryClear_btn = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Female_rdbtn = new System.Windows.Forms.RadioButton();
            this.Male_rdbtn = new System.Windows.Forms.RadioButton();
            this.AdoptSelected_btn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.testLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.SearchRegistry_dt)).BeginInit();
            this.panel4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // DisplaySearch_btn
            // 
            resources.ApplyResources(this.DisplaySearch_btn, "DisplaySearch_btn");
            this.DisplaySearch_btn.Name = "DisplaySearch_btn";
            this.DisplaySearch_btn.UseVisualStyleBackColor = true;
            this.DisplaySearch_btn.Click += new System.EventHandler(this.DisplaySearch_btn_Click);
            // 
            // SearchRegistry_dt
            // 
            this.SearchRegistry_dt.BackgroundColor = System.Drawing.SystemColors.ButtonShadow;
            resources.ApplyResources(this.SearchRegistry_dt, "SearchRegistry_dt");
            this.SearchRegistry_dt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.SearchRegistry_dt.Name = "SearchRegistry_dt";
            this.SearchRegistry_dt.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.SearchRegistry_dt.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Attempt2_CellContentClick);
            // 
            // Dog_rdbtn
            // 
            resources.ApplyResources(this.Dog_rdbtn, "Dog_rdbtn");
            this.Dog_rdbtn.Name = "Dog_rdbtn";
            this.Dog_rdbtn.TabStop = true;
            this.Dog_rdbtn.UseVisualStyleBackColor = true;
            this.Dog_rdbtn.CheckedChanged += new System.EventHandler(this.Dog_rdbtn_CheckedChanged);
            // 
            // Cat_rdbtn
            // 
            resources.ApplyResources(this.Cat_rdbtn, "Cat_rdbtn");
            this.Cat_rdbtn.Name = "Cat_rdbtn";
            this.Cat_rdbtn.TabStop = true;
            this.Cat_rdbtn.UseVisualStyleBackColor = true;
            // 
            // SpecialCare_ckbk
            // 
            resources.ApplyResources(this.SpecialCare_ckbk, "SpecialCare_ckbk");
            this.SpecialCare_ckbk.Name = "SpecialCare_ckbk";
            this.SpecialCare_ckbk.UseVisualStyleBackColor = true;
            // 
            // Mature_ckbx
            // 
            resources.ApplyResources(this.Mature_ckbx, "Mature_ckbx");
            this.Mature_ckbx.Name = "Mature_ckbx";
            this.Mature_ckbx.UseVisualStyleBackColor = true;
            // 
            // Pets_ckbx
            // 
            resources.ApplyResources(this.Pets_ckbx, "Pets_ckbx");
            this.Pets_ckbx.Name = "Pets_ckbx";
            this.Pets_ckbx.UseVisualStyleBackColor = true;
            // 
            // Kids_ckbx
            // 
            resources.ApplyResources(this.Kids_ckbx, "Kids_ckbx");
            this.Kids_ckbx.Name = "Kids_ckbx";
            this.Kids_ckbx.UseVisualStyleBackColor = true;
            this.Kids_ckbx.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.testLabel);
            this.panel4.Controls.Add(this.RegisteryClear_btn);
            this.panel4.Controls.Add(this.groupBox3);
            this.panel4.Controls.Add(this.groupBox2);
            this.panel4.Controls.Add(this.AdoptSelected_btn);
            this.panel4.Controls.Add(this.DisplaySearch_btn);
            this.panel4.Controls.Add(this.groupBox1);
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // RegisteryClear_btn
            // 
            resources.ApplyResources(this.RegisteryClear_btn, "RegisteryClear_btn");
            this.RegisteryClear_btn.Name = "RegisteryClear_btn";
            this.RegisteryClear_btn.UseVisualStyleBackColor = true;
            this.RegisteryClear_btn.Click += new System.EventHandler(this.RegisteryClear_btn_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.SpecialCare_ckbk);
            this.groupBox3.Controls.Add(this.Mature_ckbx);
            this.groupBox3.Controls.Add(this.Kids_ckbx);
            this.groupBox3.Controls.Add(this.Pets_ckbx);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Female_rdbtn);
            this.groupBox2.Controls.Add(this.Male_rdbtn);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // Female_rdbtn
            // 
            resources.ApplyResources(this.Female_rdbtn, "Female_rdbtn");
            this.Female_rdbtn.Name = "Female_rdbtn";
            this.Female_rdbtn.TabStop = true;
            this.Female_rdbtn.UseVisualStyleBackColor = true;
            // 
            // Male_rdbtn
            // 
            resources.ApplyResources(this.Male_rdbtn, "Male_rdbtn");
            this.Male_rdbtn.Name = "Male_rdbtn";
            this.Male_rdbtn.TabStop = true;
            this.Male_rdbtn.UseVisualStyleBackColor = true;
            // 
            // AdoptSelected_btn
            // 
            resources.ApplyResources(this.AdoptSelected_btn, "AdoptSelected_btn");
            this.AdoptSelected_btn.Name = "AdoptSelected_btn";
            this.AdoptSelected_btn.UseVisualStyleBackColor = true;
            this.AdoptSelected_btn.Click += new System.EventHandler(this.AdoptSelected_btn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Cat_rdbtn);
            this.groupBox1.Controls.Add(this.Dog_rdbtn);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // testLabel
            // 
            resources.ApplyResources(this.testLabel, "testLabel");
            this.testLabel.Name = "testLabel";
            // 
            // AdoptionDatabase
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.SearchRegistry_dt);
            this.MaximizeBox = false;
            this.Name = "AdoptionDatabase";
            this.Load += new System.EventHandler(this.Adoption_Database_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SearchRegistry_dt)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button DisplaySearch_btn;
        private System.Windows.Forms.DataGridView SearchRegistry_dt;
        private System.Windows.Forms.RadioButton Dog_rdbtn;
        private System.Windows.Forms.RadioButton Cat_rdbtn;
        private System.Windows.Forms.CheckBox SpecialCare_ckbk;
        private System.Windows.Forms.CheckBox Mature_ckbx;
        private System.Windows.Forms.CheckBox Pets_ckbx;
        private System.Windows.Forms.CheckBox Kids_ckbx;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button AdoptSelected_btn;
        private System.Windows.Forms.RadioButton Female_rdbtn;
        private System.Windows.Forms.RadioButton Male_rdbtn;
        private System.Windows.Forms.Button RegisteryClear_btn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label testLabel;
    }
}